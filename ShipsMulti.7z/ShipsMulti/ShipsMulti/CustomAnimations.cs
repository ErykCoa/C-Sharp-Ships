﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media.Animation;

namespace ShipsMulti
{
    public partial class MainWindow : Window
    {
        private void FieldsFadeIn(int Index = 0)
        {
            if (Index == Consts.BoardLength) return;

            Binding Binding = new Binding();
            Binding.Path = new PropertyPath("Opacity");
            Binding.Source = PlayersFields[Index, Index];

            for (int i = 10 - Index; i-- > 0;)
            {
                BindingOperations.SetBinding(PlayersFields[Index + i, Index], OpacityProperty, Binding);
                BindingOperations.SetBinding(PlayersFields[Index, Index + i], OpacityProperty, Binding);
                BindingOperations.SetBinding(OpponentsFields[Index + i, Index], OpacityProperty, Binding);
                BindingOperations.SetBinding(OpponentsFields[Index, Index + i], OpacityProperty, Binding);

                PlayersFields[Index + i, Index].Visibility = Visibility.Visible;
                OpponentsFields[Index + i, Index].Visibility = Visibility.Visible;
                PlayersFields[Index, Index + i].Visibility = Visibility.Visible;
                OpponentsFields[Index, Index + i].Visibility = Visibility.Visible;
            }

            DoubleAnimation Animation = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(Consts.DurationOfAnimations*3/2));
            Animation.Completed += new EventHandler((s, e) => FieldsFadeIn(++Index));
            PlayersFields[Index, Index].BeginAnimation(OpacityProperty, Animation);
        }

        private void GridsFadeIn()
        {
            PlayersBoard.Visibility = Visibility.Visible;
            OpponentsBoard.Visibility = Visibility.Visible;

            PlayersBoard.FadeIn();
            OpponentsBoard.FadeIn();     
        }

        private void GridsFadeOut()
        {
            PlayersBoard.FadeOut();
            OpponentsBoard.FadeOut();
        }

    }
}
