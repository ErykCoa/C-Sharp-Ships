﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;

namespace ShipsMulti
{
    public partial class MainWindow : Window
    {
        private void FillGrid(Grid Grid, Button[,] Table)
        {
            for (int IndexX = Consts.BoardLength; IndexX-- > 0;)
            {
                var Column = new ColumnDefinition();
                Column.Width = new GridLength(Grid.Width / Consts.BoardLength);
                Grid.ColumnDefinitions.Add(Column);

                for (int IndexY = Consts.BoardLength; IndexY-- > 0;)
                {
                    var Row = new RowDefinition();
                    Row.Height = new GridLength(Grid.Height / Consts.BoardLength);
                    Grid.RowDefinitions.Add(Row);

                    Grid.Children.Add(PrepareCell(out Table[IndexX, IndexY], IndexX, IndexY));
                }
            }
        }

        private Button PrepareCell(out Button Button, int Column, int Row)
        {
            Button = new Button();
            Button.Visibility = Visibility.Hidden;

            Grid.SetColumn(Button, Column);
            Grid.SetRow(Button, Row);

            return Button;
        }

        private void SwapGridsPositions(Grid First, Grid Second)
        {
            var Swap = First.Margin;
            First.Margin = Second.Margin;
            Second.Margin = Swap;

            var Swap2 = First.HorizontalAlignment;
            First.HorizontalAlignment = Second.HorizontalAlignment;
            Second.HorizontalAlignment = Swap2;

            var Swap3 = First.VerticalAlignment;
            First.VerticalAlignment = Second.VerticalAlignment;
            Second.VerticalAlignment = Swap3;
        }
    }
}
