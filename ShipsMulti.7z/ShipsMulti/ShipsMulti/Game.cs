﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace ShipsMulti
{
    class Game : IGame
    {
        public Player CurrentPlayer;

        public Game(Button[,] PlayersFields, Button[,] OpponentsFields, GameMode Mode)
        {
            if(Mode == GameMode.MultiPlayer) CurrentPlayer = new Player(PlayersFields, OpponentsFields, "Left");
            else CurrentPlayer = new Player(PlayersFields, OpponentsFields, "Left", GameMode.SinglePlayer);
        }

        public bool CurrentPlayerHasWon()
        {
            return !CurrentPlayer.Opponent.HasFloatingShips() && CurrentPlayer.Opponent.HasPlacedShips;
        }

        public void LoadLastSave()
        {
            throw new NotImplementedException();
        }

        public void NextTurn()
        {
            CurrentPlayer = CurrentPlayer.Opponent;
            CurrentPlayer.ColorFields();
        }

        public void SaveCurrentState()
        {
            throw new NotImplementedException();
        }

        public Player GetCurrentPlayer()
        {
            return CurrentPlayer;
        }
    }
}
