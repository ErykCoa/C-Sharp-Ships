﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace ShipsMulti
{
    class Player
    {
        public string Name;

        public bool IsAI { get; protected set; }

        public bool HasPlacedShips;
        public List<Ship> Ships;

        public FieldState[,] HitsAndMisses;

        public Button[,] PlayersFields { get; private set; }
        public Button[,] OpponentsFields { get; private set; }
        public Player Opponent { get; private set; }

        public Player(Button[,] PlayersFields, Button[,] OpponentsFields, string Name, GameMode Mode = GameMode.MultiPlayer, Player Opponent = null)
        {
            IsAI = false;

            this.Name = Name;

            this.PlayersFields = PlayersFields;
            this.OpponentsFields = OpponentsFields;

            if (Mode == GameMode.SinglePlayer)
                if (Opponent == null) this.Opponent = new AI(PlayersFields, OpponentsFields, this);
                else { this.Opponent = Opponent; }
            else
                if (Opponent == null) this.Opponent = new Player(PlayersFields, OpponentsFields, "Right", GameMode.MultiPlayer, this);
            else { this.Opponent = Opponent; }

            HitsAndMisses = new FieldState[Consts.BoardLength, Consts.BoardLength];

            Ships = new List<Ship>();

            HasPlacedShips = false;
        }

        public virtual void StartTurn() { }
        public FieldState FireAtOpponent(Coordinates Field)
        {
            foreach (var Ship in Opponent.Ships)
                if (!Ship.IsFieldFree(Field))
                {
                    Ship.Hit(Field);
                    if (Ship.State == ShipState.Drowned) Ship.MarkDrownedShip(HitsAndMisses);
                    return HitsAndMisses[Field.X, Field.Y] = FieldState.Hited;
                }
            return HitsAndMisses[Field.X, Field.Y] = FieldState.Missed;
        }

        public bool ShipCanBePlaced(Coordinates Start, Direction Direction, int Length)
        {
            switch(Direction)
            {
                case Direction.Up:
                    {
                        if (Start.Y - Length + 1 < 0 || Start.X >= Consts.BoardLength) return false;

                        foreach (var Ship in Ships)
                            for (int Index = Length; Index-- > 0;)
                                if (Ship.IsFieldNearby(new Coordinates(Start.X, Start.Y - Index))) return false;

                        return true;
                    }

                case Direction.Right:
                    {
                        if (Start.X + Length > Consts.BoardLength || Start.Y >= Consts.BoardLength) return false;

                        foreach (var Ship in Ships)
                            for (int Index = Length; Index-- > 0;)
                                if (Ship.IsFieldNearby(new Coordinates(Start.X + Index, Start.Y))) return false;

                        return true;
                    }
                default: return false;
            }
        }

        public void PlaceShip(Coordinates Start, Direction Direction, int Length)
        {
            if (Direction == Direction.Right) Ships.Add(new Ship(Start, new Coordinates(Start.X + Length -1, Start.Y)));
            else Ships.Add(new Ship(Start, new Coordinates(Start.X, Start.Y - Length + 1)));
        }
        
        public bool HasFloatingShips()
        {
            foreach (var Ship in Ships)
                if (Ship.State == ShipState.Floating) return true;
            
            return false;
        }

        public void ColorFields()
        {
            Brush Brush = Consts.Blue;

            for (int IndexX = Consts.BoardLength; IndexX-- > 0;)
                for (int IndexY = Consts.BoardLength; IndexY-- > 0;)
                {
                    switch (Opponent.HitsAndMisses[IndexX, IndexY])
                    {
                        case FieldState.Unknown: Brush = Consts.Blue; break;
                        case FieldState.Hited: Brush = Consts.Red; break;
                        case FieldState.Missed: Brush = Consts.White; break;
                    }

                    PlayersFields[IndexX, IndexY].Background = Brush;

                    switch (HitsAndMisses[IndexX, IndexY])
                    {
                        case FieldState.Unknown: Brush = Consts.Blue; break;
                        case FieldState.Hited: Brush = Consts.Red; break;
                        case FieldState.Missed: Brush = Consts.White; break;
                    }

                    OpponentsFields[IndexX, IndexY].Background = Brush;                 
                }

            foreach (var Ship in Ships)
                foreach (var C in Ship.FieldsCoordinates)
                    if (PlayersFields[C.X, C.Y].Background != Consts.Red) PlayersFields[C.X, C.Y].Background = Consts.Green;
        }
    }
}
