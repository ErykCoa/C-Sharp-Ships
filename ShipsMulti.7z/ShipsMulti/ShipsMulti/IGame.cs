﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShipsMulti
{
    interface IGame
    {
        bool CurrentPlayerHasWon();
        void NextTurn();
        void SaveCurrentState();
        void LoadLastSave();
        Player GetCurrentPlayer();
    }
}
