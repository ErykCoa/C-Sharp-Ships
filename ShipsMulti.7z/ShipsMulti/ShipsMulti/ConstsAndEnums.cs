﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Media;

namespace ShipsMulti
{
    public static class Consts
    {
        public const int BoardLength = 10;
        public const int DurationOfAnimations = 100;

        public static Brush Blue = new SolidColorBrush(Colors.Blue);
        public static Brush Red = new SolidColorBrush(Colors.DarkRed);
        public static Brush Green = new SolidColorBrush(Colors.DarkGreen);
        public static Brush White = new SolidColorBrush(Colors.White);

        public static int[] ShipsLengths = { 5, 4, 3, 3, 2, 0 };

        static Consts()
        {
            White.Opacity = Blue.Opacity =  0.7;
        }
    }
    enum FieldState
    {
        Unknown = 0 , Hited, Missed
    }
    enum Direction
    {
        Up, Right, None
    }
    enum ShipState
    {
        NotPlaced, Drowned, Floating
    }

    enum GameMode
    {
        SinglePlayer, MultiPlayer
    }
}
