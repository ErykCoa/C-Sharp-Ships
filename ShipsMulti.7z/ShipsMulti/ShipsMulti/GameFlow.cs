﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace ShipsMulti
{
    public partial class MainWindow : Window
    {
        private void StartNextTurn()
        {
            EndTurn();

            if (Game.GetCurrentPlayer().IsAI)
            {
                Game.GetCurrentPlayer().StartTurn();
                EndTurn();
                Tip.Visibility = Visibility.Hidden;
                return;
            }

            GridsFadeOut();

            NextTurnMsg.Text = $"{ Game.GetCurrentPlayer().Name } Player's Turn";

            NextTurnButton.Visibility = Visibility.Visible;
        }

        private void EndTurn()
        {
            if (Game.CurrentPlayerHasWon())
            {
                GridsFadeOut();
                VictoryMsg.Text = $"Player { Game.GetCurrentPlayer().Name } is victorious!";
                VictoryGrid.Visibility = Visibility.Visible;
                return;
            }
            Game.NextTurn();
        }
    }
}
