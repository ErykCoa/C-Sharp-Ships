﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShipsMulti
{
    class Ship
    {
        public ShipState State;

        private int Length;
        private bool[] Hits;

        private Direction Direction;

        private Coordinates Start;
        private Coordinates End;

        public Coordinates[] FieldsCoordinates;

        private static int ShipIndex = 0;
        public static int? NextShipLength {
            get
            {
                if (Consts.ShipsLengths[ShipIndex] > 0) return Consts.ShipsLengths[ShipIndex++];
                ShipIndex = 0; return null;
            }
            set { ShipIndex = (int)value; }
        }

        public Ship(Coordinates Start, Coordinates End)
        {
            State = ShipState.Floating;

            this.Start = Start;
            this.End = End;

            if (Start.X - End.X != 0)
            {
                Length = End.X - Start.X + 1;
                Direction = Direction.Right;
            }
            else
            {
                Length = Start.Y - End.Y + 1;              
                Direction = Direction.Up;
            }

            FieldsCoordinates = new Coordinates[Length];

            if (Direction == Direction.Right)  
                for (int Index = Length; Index-- > 0;)
                    FieldsCoordinates[Index] = new Coordinates(Start.X + Index, Start.Y);
            else
                for (int Index = Length; Index-- > 0;)
                    FieldsCoordinates[Index] = new Coordinates(Start.X, Start.Y - Index);

            Hits = new bool[Length];
        }

        public bool IsFieldFree(Coordinates Field)
        {
            foreach (Coordinates C in FieldsCoordinates)
                if (Field == C) return false;

            return true;
        }

        public bool IsFieldNearby(Coordinates Field)
        {
            if (Direction == Direction.Right && (Start.Y == Field.Y || Start.Y - 1 == Field.Y || Start.Y + 1 == Field.Y))
            {
                for (int Index = Length + 1; Index-- >= 0;)
                    if (Start.X + Index == Field.X) return true;
            }
            else if (Direction == Direction.Up && (Start.X == Field.X || Start.X - 1 == Field.X || Start.X + 1 == Field.X))
            {
                for (int Index = Length + 1; Index-- >= 0;)
                    if (Start.Y - Index == Field.Y) return true;
            }

            return false;
        }

        public void Hit(Coordinates Field)
        {
            if (Direction == Direction.Right) Hits[Field.X - Start.X] = true;
            else Hits[Start.Y -Field.Y ] = true;

            for (int Index = Length; Index-- > 0;)
                if (!Hits[Index]) return;

            State = ShipState.Drowned;
        }

        public void MarkDrownedShip(FieldState[,] HitsAndMisses)
        {
            if (Direction == Direction.Right)
            {
                for (int Y = Start.Y - 1; Y <= Start.Y + 1; Y++)
                    if (Y >= 0 && Y < Consts.BoardLength)
                        for (int X = Start.X + Length + 1; X-- >= Start.X;)
                            if (X >= 0 && X < Consts.BoardLength && HitsAndMisses[X, Y] != FieldState.Hited) HitsAndMisses[X, Y] = FieldState.Missed;
            }
            else
            {
                for (int X = Start.X - 1; X <= Start.X + 1; X++)
                    if (X >= 0 && X < Consts.BoardLength)
                        for (int Y = Start.Y - Length - 1; Y++ <= Start.Y;)
                            if (Y >= 0 && Y < Consts.BoardLength && HitsAndMisses[X, Y] != FieldState.Hited) HitsAndMisses[X, Y] = FieldState.Missed;
            }
        }
    }
}
