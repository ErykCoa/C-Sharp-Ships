﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace ShipsMulti
{
    public partial class MainWindow : Window
    {
        private void AddClickEventHandler(Button[,] Table, Func Handler)
        {
            for (int IndexX = Consts.BoardLength; IndexX-- > 0;)
                for (int IndexY = Consts.BoardLength; IndexY-- > 0;)
                    Table[IndexX, IndexY].Click += new RoutedEventHandler(Handler);
        }

        private void AddHoverEventHandler(Button[,] Table, Func EnterHandler, Func LeaveHandler)
        {
            for (int IndexX = Consts.BoardLength; IndexX-- > 0;)
                for (int IndexY = Consts.BoardLength; IndexY-- > 0;)
                {
                    Table[IndexX, IndexY].MouseEnter += new MouseEventHandler(EnterHandler);
                    Table[IndexX, IndexY].MouseLeave += new MouseEventHandler(LeaveHandler);
                }
        }

        private void ClickPlayersField(object Sender, EventArgs Args)
        {
            if (Game.GetCurrentPlayer().HasPlacedShips) return;

            Coordinates ButtonPosition = ((Button)Sender).FindButton();

            if (Game.GetCurrentPlayer().ShipCanBePlaced(ButtonPosition, Direction, ShipLength))
            {
                Game.GetCurrentPlayer().PlaceShip(ButtonPosition, Direction, ShipLength);

                int? NextShipLength = Ship.NextShipLength;

                if (NextShipLength == null)
                {
                    Game.GetCurrentPlayer().HasPlacedShips = true;
                    ShipLength = (int)Ship.NextShipLength;

                    StartNextTurn();
                }
                else
                {
                    ShipLength = (int)NextShipLength;
                    LeavePlayersField(Sender, Args);
                    EnterPlayersField(Sender, Args);
                }
            }
        }
        private void ClickOpponentsField(object Sender, EventArgs Args)
        {
            if (!Game.GetCurrentPlayer().HasPlacedShips) return;

            var Field = ((Button)Sender).FindButton();

            switch (Game.GetCurrentPlayer().HitsAndMisses[Field.X, Field.Y])
            {
                case FieldState.Missed:
                case FieldState.Hited: return;
                case FieldState.Unknown: Game.GetCurrentPlayer().FireAtOpponent(((Button)Sender).FindButton()); break;
            }

            if (Game.GetCurrentPlayer().HitsAndMisses[Field.X, Field.Y] == FieldState.Missed || Game.CurrentPlayerHasWon())
                StartNextTurn();
            else
                Game.GetCurrentPlayer().ColorFields();
        }

        private void EnterPlayersField(object Sender, EventArgs Args)
        {
            if (Game.GetCurrentPlayer().HasPlacedShips) return;

            Coordinates ButtonPosition = ((Button)Sender).FindButton();     

            Brush Brush;

            if (Game.GetCurrentPlayer().ShipCanBePlaced(ButtonPosition, Direction, ShipLength))
                Brush = Brushes.Green;
            else
                Brush = Brushes.Red;

            if (Direction == Direction.Right)
            {
                for (int X = ButtonPosition.X; X <= ButtonPosition.X + ShipLength - 1; X++)
                    if (X < Consts.BoardLength && X >= 0) Game.GetCurrentPlayer().PlayersFields[X, ButtonPosition.Y].Background = Brush;
            }
            else
            {
                for (int Y = ButtonPosition.Y; Y >= ButtonPosition.Y - ShipLength + 1; Y--)
                    if (Y < Consts.BoardLength && Y >= 0) Game.GetCurrentPlayer().PlayersFields[ButtonPosition.X, Y].Background = Brush;
            }

        }

        private void LeavePlayersField(object Sender, EventArgs Args) => Game.GetCurrentPlayer().ColorFields();

        private void ClickSinglePlayer(object Sender, EventArgs Args)
        {
            Game = new Game(PlayersFields, OpponentsFields, GameMode.SinglePlayer);
            Game.GetCurrentPlayer().ColorFields();

            TitleScreen.Visibility = Visibility.Hidden;

            Tip.Visibility = Visibility.Visible;

            GridsFadeIn();
            FieldsFadeIn();
        }

        private void ClickMultiPlayer(object Sender, EventArgs Args)
        {
            Game = new Game(PlayersFields, OpponentsFields, GameMode.MultiPlayer);
            Game.GetCurrentPlayer().ColorFields();

            TitleScreen.Visibility = Visibility.Hidden;

            Tip.Visibility = Visibility.Visible;

            GridsFadeIn();
            FieldsFadeIn();
        }

        private void ClickNextTurn(object Sender, EventArgs Args)
        {
            ((Button)Sender).Visibility = Visibility.Hidden;

            SwapGridsPositions(PlayersBoard, OpponentsBoard);

            GridsFadeIn();

            if(!Game.GetCurrentPlayer().HasFloatingShips()) Tip.Visibility = Visibility.Visible;
        }
    }
}
