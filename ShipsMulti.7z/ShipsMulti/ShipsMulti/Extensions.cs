﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace ShipsMulti
{
    static class Extensions
    {
        public static bool Contains(this Button[,] Table, Button Button) => Table[Grid.GetColumn(Button), Grid.GetRow(Button)] == Button;
        public static Coordinates FindButton(this Button Button) => new Coordinates(Grid.GetColumn(Button), Grid.GetRow(Button));
        public static void FadeIn(this Grid Grid)
        {
            DoubleAnimation Animation = new DoubleAnimation(0, 1, TimeSpan.FromMilliseconds(Consts.DurationOfAnimations));
            Grid.Visibility = Visibility.Visible;           
            Grid.BeginAnimation(UIElement.OpacityProperty, Animation);           
        }
        public static void FadeOut(this Grid Grid)
        {
            DoubleAnimation Animation = new DoubleAnimation(1, 0, TimeSpan.FromMilliseconds(Consts.DurationOfAnimations));
            Animation.Completed += new EventHandler((s, e) => Grid.Visibility = Visibility.Hidden);
            Grid.BeginAnimation(UIElement.OpacityProperty, Animation);
        }
    }
}
