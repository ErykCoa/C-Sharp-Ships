﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShipsMulti
{
    struct Coordinates
    {
        public int X;
        public int Y;

        public Coordinates(int X, int Y)
        {
            this.X = X;
            this.Y = Y;
        }

        public static bool operator ==(Coordinates First, Coordinates Second)
        {
            return First.X == Second.X && First.Y == Second.Y;
        }

        public static bool operator !=(Coordinates First, Coordinates Second)
        {
            return First.X != Second.X || First.Y != Second.Y;
        }
    }
}
