﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;

namespace ShipsMulti
{
    public partial class MainWindow : Window
    {
        void RKeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.R)
            {
                if (Direction == Direction.Up) Direction = Direction.Right;
                else Direction = Direction.Up;

                Game.GetCurrentPlayer().ColorFields();

                var Element = Mouse.DirectlyOver as UIElement;
                if (Element == null) return;

                var ButtonUnderCursor = VisualTreeHelper.GetParent(Element);
                if (ButtonUnderCursor.GetType() == typeof(Button) && Game.GetCurrentPlayer().PlayersFields.Contains((Button)ButtonUnderCursor))
                    EnterPlayersField(ButtonUnderCursor, e);
            }
        }
    }
}
