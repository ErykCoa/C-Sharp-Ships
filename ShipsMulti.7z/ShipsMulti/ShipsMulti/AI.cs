﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace ShipsMulti
{
    class AI : Player
    {
        static Random Seed;

        Coordinates? FirstHitedField;

        Stack<Coordinates> NextFieldToBeShootedAt;

        Direction PresumableShipsDirection;

        public AI(Button[,] PlayersFields, Button[,] OpponentsFields, Player Opponent = null) : base (PlayersFields, OpponentsFields, "AI", GameMode.SinglePlayer, Opponent)
        {
            IsAI = true;
            Seed = new Random();
            NextFieldToBeShootedAt = new Stack<Coordinates>();
            PresumableShipsDirection = Direction.None;
            FirstHitedField = null;
        }

        public override void StartTurn()
        {
            if (!HasPlacedShips) PlaceShips();
            else FireAtOpponent();
        }

        private void PlaceShips()
        {
            Coordinates Start = new Coordinates();
            Direction Direction;

            foreach ( var Ship in Consts.ShipsLengths)
                if (Ship != 0)
                {
                    do
                    {
                        Start.X = Seed.Next(Consts.BoardLength);
                        Start.Y = Seed.Next(Consts.BoardLength);
                        Direction = (Seed.Next(2) > 0) ? Direction.Up : Direction.Right;
                    } while (!ShipCanBePlaced(Start, Direction, Ship));

                    PlaceShip(Start, Direction, Ship);
                }

            HasPlacedShips = true;
        }

        private void FireAtOpponent()
        {
            ClearWrongItemsFromStack();

            if (!NextFieldToBeShootedAt.Any())
            {
                FirstHitedField = null;
                PresumableShipsDirection = Direction.None;

                var Field = new Coordinates();
                do
                {
                    Field.X = Seed.Next(Consts.BoardLength);
                    Field.Y = Seed.Next(Consts.BoardLength);
                } while (HasBeenShooted(Field));

                NextFieldToBeShootedAt.Push(Field);
            }

            if (FireAtOpponent(NextFieldToBeShootedAt.Peek()) == FieldState.Hited)
            {
                if (FirstHitedField != null)
                {
                    if (NextFieldToBeShootedAt.Peek().X == ((Coordinates)FirstHitedField).X) PresumableShipsDirection = Direction.Up;
                    else PresumableShipsDirection = Direction.Right;
                }
                else FirstHitedField = NextFieldToBeShootedAt.Peek();

                AddSurroundingFields(NextFieldToBeShootedAt.Pop());

                FireAtOpponent();
            }
            else NextFieldToBeShootedAt.Pop();
        }

        private void ClearWrongItemsFromStack()
        {
            for(Coordinates Field; NextFieldToBeShootedAt.Any();)
            {
                    Field = NextFieldToBeShootedAt.Peek();
                    if (!IsOnBoard(Field) || !IsDirectionCorrect(Field) || HasBeenShooted(Field)) NextFieldToBeShootedAt.Pop(); 
                    else return;
            }
        }

        private bool IsOnBoard(Coordinates Field)
        {
            return Field.X < Consts.BoardLength && Field.X >= 0 && Field.Y < Consts.BoardLength && Field.Y >= 0;
        }

        private bool IsDirectionCorrect(Coordinates Field)
        {
            switch (PresumableShipsDirection)
            {
                case Direction.Up: if (((Coordinates)FirstHitedField).X != Field.X) return false; break;
                case Direction.Right: if (((Coordinates)FirstHitedField).Y != Field.Y) return false; break;
                default: break;
            }
            return true;
        }

        private bool HasBeenShooted(Coordinates Field)
        {
            if (HitsAndMisses[Field.X, Field.Y] != FieldState.Unknown) return true;
            return false;
        }

        private void AddSurroundingFields(Coordinates Field)
        {
            switch (PresumableShipsDirection)
            {
                case Direction.Up:
                    {
                        if (IsOnBoard(new Coordinates(Field.X, Field.Y + 1))) NextFieldToBeShootedAt.Push(new Coordinates(Field.X, Field.Y + 1));
                        if (IsOnBoard(new Coordinates(Field.X, Field.Y - 1))) NextFieldToBeShootedAt.Push(new Coordinates(Field.X, Field.Y - 1));
                        break;
                    }
                case Direction.Right:
                    {
                        if (IsOnBoard(new Coordinates(Field.X + 1, Field.Y))) NextFieldToBeShootedAt.Push(new Coordinates(Field.X + 1, Field.Y));
                        if (IsOnBoard(new Coordinates(Field.X - 1, Field.Y))) NextFieldToBeShootedAt.Push(new Coordinates(Field.X - 1, Field.Y));
                        break;
                    }
                default:
                    {
                        if (IsOnBoard(new Coordinates(Field.X + 1, Field.Y))) NextFieldToBeShootedAt.Push(new Coordinates(Field.X + 1, Field.Y));
                        if (IsOnBoard(new Coordinates(Field.X - 1, Field.Y))) NextFieldToBeShootedAt.Push(new Coordinates(Field.X - 1, Field.Y));
                        if (IsOnBoard(new Coordinates(Field.X, Field.Y + 1))) NextFieldToBeShootedAt.Push(new Coordinates(Field.X, Field.Y + 1));
                        if (IsOnBoard(new Coordinates(Field.X, Field.Y - 1))) NextFieldToBeShootedAt.Push(new Coordinates(Field.X, Field.Y - 1));
                        break;
                    }
            }
        }
    }
}
