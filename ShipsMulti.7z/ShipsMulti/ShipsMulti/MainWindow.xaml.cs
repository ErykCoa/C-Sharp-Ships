﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ShipsMulti
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private int ShipLength;
        private Direction Direction;
        private IGame Game;

        private Button[,] PlayersFields;
        private Button[,] OpponentsFields;

        private delegate void Func(object Sender, EventArgs Args);

        public MainWindow()
        {
            InitializeComponent();

            KeyDown += new KeyEventHandler(RKeyDown);

            PlayersFields = new Button[Consts.BoardLength, Consts.BoardLength];
            OpponentsFields = new Button[Consts.BoardLength, Consts.BoardLength];

            FillGrid(PlayersBoard, PlayersFields);
            FillGrid(OpponentsBoard, OpponentsFields);

            AddHoverEventHandler(PlayersFields, EnterPlayersField, LeavePlayersField);
            AddClickEventHandler(PlayersFields, ClickPlayersField);

            AddClickEventHandler(OpponentsFields, ClickOpponentsField);           

            ShipLength = (int) Ship.NextShipLength;

            Direction = Direction.Up;           
        }          
    }
}
